:- module('5c62-6894-a207-8ef9.GC02WX0NQJG5ME',[]).
targetVar(['_DummyVar']).
qresult([true]) :- true.

