:- module('a2a0-6213-0ba5-7abd.GC02WX0NQJG5ME',[]).
targetVar(['Res','Trace']).
:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/TableAndEquation.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/demo.dialog.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/ScienceKnowledge.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/SadlBaseModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/SadlImplicitModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/MetaModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/SadlListModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/DBN.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/ScientificConcepts2.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/CompGraphModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/Hypersonics_v2.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/OwlModels/SadlBuiltinFunctions.owl').

:- load_rdf_file('/Users/alfredo/Documents/workspace-201812/ASKE/ComputationalGraphModels/Q_1572377662553.owl').

qresult([Res,Trace]) :- model_satisfies_assumptions('http://aske.ge.com/Model_Q_1572377662553#CG_1572377663064', Res, Trace).

