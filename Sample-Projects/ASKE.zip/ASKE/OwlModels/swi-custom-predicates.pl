% custom predicates and initialization for SWI-Prolog should be defined here

:- consult('exp.pl').
