import math
def setDefaults():
    eta = [0]*20
    cp = [0]*20
    v = [0]*20
    s = [0]*20
    pt = [0]*20
    gam = [0]*20
    prat = [0]*20
    trat = [0]*20
    tt = [0]*20

    i = 0
    move = 0
    inptype = 0
    siztype = 0
    lunits = 0
    lconv1 = 1.0
    lconv2 = 1.0
    fconv = 1.0
    mconv1 = 1.0
    pconv = 1.0
    econv = 1.0
    aconv = 1.0
    bconv = 1.0
    mconv2 = 1.0
    dconv = 1.0
    flconv = 1.0
    econv2 = 1.0
    tconv = 1.0
    tref = 459.6
    g0 = g0d = 32.2
    counter = 0
    showcom = 0
    plttyp = 3
    pltkeep = 0
    entype = 0
    inflag = 0
    varflag = 0
    pt2flag = 0
    wtflag = 0
    fireflag = 0
    gama = 1.4
    gamopt = 1
    u0d = 0.0
    altd = 0.0
    throtl = 100.
    while i <= 19:
        trat[i] = 1.0
        tt[i] = 518.6
        prat[i] = 1.0
        pt[i] = 14.7
        eta[i] = 1.0
        i += 1
    tt[4] = tt4 = tt4d = 2500.
    tt[7] = tt7 = tt7d = 2500.
    prat[3] = p3p2d = 8.0
    prat[13] = p3fp2d = 2.0
    byprat = 1.0
    abflag = 0
    fueltype = 0
    fhvd = fhv = 18600.
    a2d = a2 = acore = 2.0
    diameng = math.sqrt(4.0 * a2d / 3.14159)
    ac = 0.9 * a2
    a8rat = 0.35
    a8 = 0.7
    a8d = 0.40
    arsched = 0
    afan = 2.0
    a4 = 0.418
    athsched = 1
    aexsched = 1
    arthmn = 0.1
    arthmx = 1.5
    arexmn = 1.0
    arexmx = 10.0
    arthd = arth = 0.4
    arexit = arexitd = 3.0
    u0mt = 1500.
    u0mr = 4500.
    altmt = 60000.
    altmr = 100000.
    u0min = 0.0
    u0max = u0mt
    altmin = 0.0
    altmax = altmt
    thrmin = 30
    thrmax = 100
    etmin = 0.5
    etmax = 1.0
    cprmin = 1.0
    cprmax = 50.0
    bypmin = 0.0
    bypmax = 10.0
    fprmin = 1.0
    fprmax = 2.0
    t4min = 1000.0
    t4max = 3200.0
    t7min = 1000.0
    t7max = 4000.0
    a8min = 0.1
    a8max = 0.4
    a2min = 0.001
    a2max = 50.
    pt4max = 1.0
    diamin = math.sqrt(4.0 * a2min / 3.14159)
    diamax = math.sqrt(4.0 * a2max / 3.14159)
    pmax = 6000.0
    tmin = -300.0 + tref
    tmax = 600.0 + tref
    vmn1 = u0min
    vmx1 = u0max
    vmn2 = altmin
    vmx2 = altmax
    vmn3 = thrmin
    vmx3 = thrmax
    vmn4 = arexmn
    vmx4 = arexmx
    xtrans = 125.0
    ytrans = 115.0
    factor = 35.
    sldloc = 75
    xtranp = 80.0
    ytranp = 180.0
    factp = 27.
    sldplt = 130
    weight = 1000.
    minlt = 1
    dinlt = 170.2
    tinlt = 900.
    mfan = 2
    dfan = 293.02
    tfan = 1500.
    mcomp = 2
    dcomp = 293.02
    tcomp = 1500.
    mburner = 4
    dburner = 515.2
    tburner = 2500.
    mturbin = 4
    dturbin = 515.2
    tturbin = 2500.
    mnozl = 3
    dnozl = 515.2
    tnozl = 2500.
    mnozr = 5
    dnozr = 515.2
    tnozr = 4500.
    ncflag = 0
    ntflag = 0

    ncomp = (int) (1.0 + p3p2d / 1.5) 
    if ncomp > 15: 
       ncomp = 15 

    hblade = math.sqrt(2.0/3.1415926)
    lburn = hblade

    sblade = .02
    hblade = math.sqrt(2.0/3.1415926)
    tblade = .2*hblade

    xcomp = ncomp*(tblade+sblade)
    lcomp = xcomp

    lnoz = lburn 
    if entype == 1:
          lnoz = 3.0 * lburn 
    if entype == 3:
      lnoz = 3.0 * lburn 

    if ntflag == 0 :
       nturb = 1 + ncomp/4 
       if entype == 2:
          nturb = nturb + 1

    lturb = nturb*(tblade+sblade)


    return
