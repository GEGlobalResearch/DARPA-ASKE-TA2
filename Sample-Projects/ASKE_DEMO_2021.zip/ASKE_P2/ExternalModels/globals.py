import math as Math
trat = [0]*20
tt   = [0]*20
prat = [0]*20
pt   = [0]*20
eta  = [0]*20
gam  = [0]*20
cp   = [0]*20
s    = [0]*20
v    = [0]*20
