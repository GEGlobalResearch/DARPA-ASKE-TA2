:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/TableAndEquation.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/test4.dialog.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/ScienceKnowledge.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/SadlBaseModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/SadlImplicitModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/MetaModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/SadlListModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/DBN.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/ScientificConcepts2.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/CompGraphModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/Hypersonics_v2.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/SadlBuiltinFunctions.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/ComputationalGraphModels/Q_1574180037229.owl').

qresult([Res,Trace]) :- model_satisfies_assumptions('http://aske.ge.com/Model_Q_1574104854437#CG_1574104863309', Res, Trace).
