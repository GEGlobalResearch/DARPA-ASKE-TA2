:- rdf_load('CompGraphModel.owl').
:- rdf_load('DBN.owl').
:- rdf_load('Hypersonics_v2.owl').
:- rdf_load('MetaData.owl').
:- rdf_load('MetaModel.owl').
:- rdf_load('SadlImplicitModel.owl').
:- rdf_load('ScienceKnowledge.owl').

