:- use_module( library(chr)).

:- chr_constraint leq/2.
:- chr_constraint lt/2.
:- chr_constraint geq/2.
:- chr_constraint gt/2.
:- chr_constraint eq/2, neq/2.
:- chr_constraint constraint/1, constr/3.
:- chr_constraint unsatisfied/1.
:- chr_constraint trace/1, step/1.
:- chr_constraint and/2.
:- chr_constraint or/2.
:- chr_constraint neg/1.

:- chr_constraint coin/0, heads/0, tails/0, red/0, blue/0, yellow/0, purple/0, green/0, blueyellow/0, a/0,b/0,ab/0,ba/0.

:- op(500, xfx, lt).
:- op(500, xfx, leq).
%% :- op(500, xfx, gt).
%% :- op(500, xfx, geq).
%% :- op(500, xfx, eq).
%% :- op(500, xfx, neq).
%% :- op(600, yfx, and).
%%:- op(600, fyx, or).
%% :- op(600, fy, neg).

inequality(_ leq _).

coin ==> heads.
coin ==> tails.
red, blue ==> purple.
red, yellow ==> orange.
yellow, blue ==> blueyellow.
blue, yellow ==> green.


%transitivity @ X lt Y , Y lt Z  ==> X \== Y, Y \== Z | X lt Z.
x lt y, y lt x ==> x lt x.
y lt x, x lt y ==> y lt y.

a, b ==> ab.
b, a ==> ba.

or(X,Y), neg(X) ==> inequality(X) | Y.
