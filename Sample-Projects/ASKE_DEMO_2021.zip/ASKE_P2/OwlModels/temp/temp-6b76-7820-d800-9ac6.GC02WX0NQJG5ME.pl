:- module('6b76-7820-d800-9ac6.GC02WX0NQJG5ME',[]).
targetVar(['Res','Trace']).
:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/TableAndEquation.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/alt_stTemp.dialog.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/demo.dialog.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/temperature_mach.dialog.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/Turbo.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/test.dialog.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/test2.dialog.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/ScienceKnowledge.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/SadlBaseModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/SadlImplicitModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/MetaModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/SadlListModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/test4.dialog.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/DBN.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/ScientificConcepts2.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/CompGraphModel.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/Isentrop.dialog.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/Hypersonics_v2.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/SadlBuiltinFunctions.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/SpeedOfSound.owl').

:- load_rdf_file('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/ComputationalGraphModels/Q_1581706722806.owl').

qresult([Res,Trace]) :- model_satisfies_assumptions('http://aske.ge.com/Model_Q_1581706722806#CG_1581706726709', Res, Trace).

