:- module('de58-2b1b-d758-4ac4.GC02WX0NQJG5ME',[]).
targetVar(['_DummyVar']).
qresult([true]) :- true.

