tmp_dir('/Users/alfredo/Documents/git/DARPA-ASKE-TA2/KnowledgeGraph/ASKE_P2/OwlModels/temp/').
port_number(5000).